# 文本素材与证据账本

研究日期：2026-10-01。对象为刘慈欣原著蓝色空间号舰长褚岩。
虚构角色没有独立著作；本维度改为小说叙事、角色发言与合法公开材料。

## 已直接核查
- Macmillan/Tor 出版社《Death's End》页：https://us.macmillan.com/books/9780765386632/deathsend/ 。确认作品、作者、英译与梗概；不覆盖褚岩主要场景。
- Tor 合法节选索引，2016-09-19：https://reactormag.com/read-selections-from-cixin-lius-deaths-end/ 。节选主要为前部人物，不是褚岩全文来源。
- 刘慈欣《Chinese Literature and Apocalyptic SF: Some Notes on Death’s End》，2016-09-20，Ken Liu 译：https://reactormag.com/chinese-literature-and-apocalyptic-sf-some-notes-on-deaths-end/ 。作者谈宇宙规律武器、末日社会与少数象征人物控制历史的写作局限。只作创作方法依据。

## 情节锚点待完整原著复核
- 《黑暗森林》末段：黑暗战役与蓝色空间号存续。舰队行为不等于褚岩全部个人决策。
- 《死神永生》威慑纪元：青铜时代号返航受审，示警蓝色空间号；万有引力号追捕。
- 《死神永生》威慑后两舰深空段：四维碎片、水滴失效、交流探索、广播投票。
- 后期银河人类：主要经关一帆叙述；不能反向宣称褚岩预知全部未来。

所有精确命令、行动顺序、表决数字、杀伤细节与人物原话未在本次完整核对，技能避免断言。
搜索结果出现未经授权全本与同人转述，未打开或下载作为证据。
